#pragma once
#WARNING("Obsolete - use /AudioTools/Communication/VBANStream.h ")
#include "AudioTools/Communication"