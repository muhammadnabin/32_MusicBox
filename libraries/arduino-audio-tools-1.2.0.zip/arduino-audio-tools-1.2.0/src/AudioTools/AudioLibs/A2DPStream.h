#pragma once
#warning("obsolete: use AudioTools/Communication/A2DPStream.h")
#include "AudioTools/Communication/A2DPStream.h"