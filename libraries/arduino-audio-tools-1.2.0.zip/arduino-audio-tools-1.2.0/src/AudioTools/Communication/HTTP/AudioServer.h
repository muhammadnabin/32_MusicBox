#pragma once

#include "AudioServerWiFi.h"
#include "AudioServerEthernet.h"