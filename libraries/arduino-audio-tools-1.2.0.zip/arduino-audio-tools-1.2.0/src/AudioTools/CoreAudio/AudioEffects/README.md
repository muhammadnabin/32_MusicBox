
This directory provides the different implementations of Audio Effects.