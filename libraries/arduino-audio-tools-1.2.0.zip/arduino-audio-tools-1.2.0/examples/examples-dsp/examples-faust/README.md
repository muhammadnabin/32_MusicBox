# Faust Examples

For details consult the [Wiki](https://github.com/pschatzmann/arduino-audio-tools/wiki/Faust)

The examples are written for the AudioKit, but you can easily just replace the AudioKitStream with an I2SStream to use a regular ESP32 module.